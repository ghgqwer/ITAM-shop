import{h as a}from"../chunks/entry.B0YtdMGf.js";export{a as start};
